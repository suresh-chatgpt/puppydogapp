import 'package:get/get.dart';
import 'package:puppy_dog/controller/puppy_controller.dart';

class PuppyBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => PuppyController());
  }
}
