import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get.dart';
import 'package:puppy_dog/utils/dialogs.dart';

class PuppyController extends GetxController {
  var dio = Dio();
  FocusNode focusNode = FocusNode();
  TextEditingController amountController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController memoController = TextEditingController();
  RxString paymentURL = "".obs;

  void updateAmount({required bool isIncrement}) {
    if (isIncrement) {
      if (amountController.text.isEmpty) {
        amountController.text = "1";
      } else {
        amountController.text = (int.parse(amountController.text.trim()) + 1).toString();
      }
    } else {
      if (amountController.text.isNotEmpty && int.parse(amountController.text.trim()) > 0) {
        amountController.text = (int.parse(amountController.text.trim()) - 1).toString();
        if (amountController.text == "0") {
          amountController.clear();
        }
      }
    }
    focusNode.unfocus();
  }

  Future<String?> paymentValidation() {
    if (amountController.text.trim().isEmpty) {
      return Future.value("Please input an amount");
    }
    if (int.parse(amountController.text.trim()) <= 0) {
      return Future.value("Amount too small");
    }
    if (int.parse(amountController.text.trim()) > 100) {
      return Future.value("Amount too large");
    }
    return Future.value(null);
  }

  Future<String?> searchPrice({required int amount}) async {
    String? priceID;
    await dio.get("https://api.stripe.com/v1/prices/search?query=lookup_key:'$amount'").then((value) {
      if (value.data["data"].isNotEmpty) {
        priceID = value.data["data"][0]["id"];
      }
    }).onError((DioError error, _) {
      if (kDebugMode) {
        print(error.response?.data);
      }
      priceID = "";
      Get.back();
      AppDialogs.errorDialog(Get.context!, errorText: "Network error");
    });
    return Future.value(priceID);
  }

  Future<String?> createPrice({required int amount}) async {
    String? priceID;
    await dio.post(
      "https://api.stripe.com/v1/prices",
      data: {
        "unit_amount": amount,
        "currency": "usd",
        "product": "prod_N7C7Z20qduLRjS",
        "lookup_key": amount,
      },
    ).then((value) {
      priceID = value.data["id"];
    }).onError((DioError error, _) {
      Get.back();
      AppDialogs.errorDialog(Get.context!, errorText: "Network error");
      if (kDebugMode) {
        print(error.response?.data);
      }
    });
    return Future.value(priceID);
  }

  Future<String?> createPaymentLink({required String priceID}) async {
    String? paymentURL;
    await dio.post(
      "https://api.stripe.com/v1/payment_links",
      data: {
        "line_items[0][price]": priceID,
        "line_items[0][quantity]": 1,
      },
    ).then((value) {
      paymentURL = value.data["url"];
    }).onError((DioError error, _) {
      Get.back();
      AppDialogs.errorDialog(Get.context!, errorText: "Network error");
      if (kDebugMode) {
        print(error.response?.data);
      }
    });
    return Future.value(paymentURL);
  }

  void requestPayment() async {
    String? message = await paymentValidation();
    if (message != null) {
      AppDialogs.errorDialog(
        Get.context!,
        errorText: message,
      );
      return;
    }

    String apiKey = dotenv.get("STRIPE_API_KEY");
    AppDialogs.loadingDialog();
    dio.options.headers["Authorization"] = "Bearer $apiKey";
    dio.options.headers["Content-Type"] = "application/x-www-form-urlencoded";
    dio.options.contentType = Headers.formUrlEncodedContentType;

    int amount = int.parse(amountController.text.trim()) * 100;
    String? priceID = await searchPrice(amount: amount);
    if (priceID == "") {
      return;
    } else {
      priceID ??= await createPrice(amount: amount);
    }

    if (priceID == null) return;

    String? url = await createPaymentLink(priceID: priceID);
    if (url == null) return;

    Get.back();
    phoneController.clear();
    memoController.clear();

    paymentURL.value = url;
    AppDialogs.paymentSentDialog(
        phoneNumber: phoneController.text.trim(), amount: int.parse(amountController.text.trim()));
  }
}
