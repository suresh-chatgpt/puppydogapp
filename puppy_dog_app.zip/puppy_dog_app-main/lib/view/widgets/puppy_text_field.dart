import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:puppy_dog/controller/puppy_controller.dart';

class PuppyTextField extends StatelessWidget {
  const PuppyTextField({
    Key? key,
    required this.hint,
    this.style,
    this.controller,
  }) : super(key: key);
  final String hint;
  final TextStyle? style;
  final TextEditingController? controller;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      focusNode: style == null ? null : Get.find<PuppyController>().focusNode,
      cursorColor: Colors.orange,
      textAlign: style == null ? TextAlign.left : TextAlign.center,
      inputFormatters: style == null ? null : [FilteringTextInputFormatter.digitsOnly],
      style: style ?? Get.textTheme.headline4,
      decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.r),
          borderSide: BorderSide(
            color: style == null ? Colors.grey : Colors.orange,
            width: style == null ? 1.w : 2.w,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.r),
          borderSide: BorderSide(
            color: Colors.orange,
            width: 2.w,
          ),
        ),
        isDense: true,
        hintText: hint,
        hintStyle:
            style != null ? style!.copyWith(color: Colors.grey) : Get.textTheme.headline4!.copyWith(color: Colors.grey),
      ),
    );
  }
}
