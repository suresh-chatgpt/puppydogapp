import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:puppy_dog/controller/puppy_controller.dart';
import 'package:puppy_dog/view/widgets/puppy_text_field.dart';

class Home extends GetWidget<PuppyController> {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.orange,
        centerTitle: true,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              "assets/svg/puppy.svg",
              height: 30.h,
              fit: BoxFit.fitHeight,
              color: Colors.white,
            ),
            5.horizontalSpace,
            Text(
              "Puppy Dog App",
              style: Get.textTheme.headline3!.copyWith(color: Colors.white),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.all(20.w),
          children: [
            Align(
              alignment: Alignment.center,
              child: Text(
                "Hello!",
                style: Get.textTheme.headline1,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Request payment",
                style: Get.textTheme.headline4,
              ),
            ),
            20.verticalSpace,
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: GestureDetector(
                    onTap: () {
                      Feedback.forTap(context);
                      controller.updateAmount(isIncrement: false);
                    },
                    child: Container(
                      alignment: Alignment.centerRight,
                      child: Container(
                        height: 30.h,
                        width: 40.w,
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(100.r),
                            bottomLeft: Radius.circular(100.r),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "-1",
                          style: Get.textTheme.headline5!.copyWith(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: PuppyTextField(
                    hint: "\$",
                    style: Get.textTheme.headline1,
                    controller: controller.amountController,
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: GestureDetector(
                    onTap: () {
                      Feedback.forTap(context);
                      controller.updateAmount(isIncrement: true);
                    },
                    child: Container(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        height: 30.h,
                        width: 40.w,
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(100.r),
                            bottomRight: Radius.circular(100.r),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "+1",
                          style: Get.textTheme.headline5!.copyWith(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            20.verticalSpace,
            PuppyTextField(
              hint: "Phone (optional)",
              controller: controller.phoneController,
            ),
            10.verticalSpace,
            PuppyTextField(
              hint: "Memo (optional)",
              controller: controller.memoController,
            ),
            10.verticalSpace,
            TextButton(
              onPressed: () {
                controller
                  ..requestPayment()
                  ..focusNode.unfocus();
              },
              style: TextButton.styleFrom(padding: EdgeInsets.zero),
              child: Container(
                height: 50.h,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.circular(10.r),
                ),
                alignment: Alignment.center,
                child: Text(
                  "Request payment",
                  style: Get.textTheme.button!.copyWith(color: Colors.white),
                ),
              ),
            ),
            10.verticalSpace,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.lock_rounded,
                  color: Colors.orange,
                  size: 15.sp,
                ),
                5.horizontalSpace,
                Text(
                  "powered by Stripe",
                  style: Get.textTheme.caption,
                ),
              ],
            ),
            5.verticalSpace,
            Divider(
              color: Colors.orange,
              thickness: 1.h,
            ),
            5.verticalSpace,
            Align(
              alignment: Alignment.center,
              child: Text(
                "Dear customer, please note;\n1) We do not store your personal information.\n2) We do not store your credit card information.\n3) We are complaint with PCI/DSS standards.",
                textAlign: TextAlign.center,
                style: Get.textTheme.headline4,
              ),
            ),
            5.verticalSpace,
            Row(
              children: [
                Expanded(
                  child: Divider(
                    color: Colors.orange,
                    thickness: 1.h,
                  ),
                ),
                10.horizontalSpace,
                SvgPicture.asset(
                  "assets/svg/pete.svg",
                  color: Colors.black,
                  height: 80.h,
                  fit: BoxFit.fitHeight,
                ),
                10.horizontalSpace,
                Expanded(
                  child: Divider(
                    color: Colors.orange,
                    thickness: 1.h,
                  ),
                ),
              ],
            ),
            5.verticalSpace,
            Align(
              alignment: Alignment.center,
              child: Text(
                "For support please call or text us:",
                style: Get.textTheme.headline4,
              ),
            ),
            5.verticalSpace,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.phone,
                  color: Colors.orange,
                  size: 20.sp,
                ),
                5.horizontalSpace,
                Icon(
                  Icons.email_rounded,
                  color: Colors.orange,
                  size: 20.sp,
                ),
                5.horizontalSpace,
                Text(
                  "+1 727 565 7296",
                  style: Get.textTheme.headline4,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
