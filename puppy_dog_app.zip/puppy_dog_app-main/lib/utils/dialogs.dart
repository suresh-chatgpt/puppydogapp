import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:pretty_qr_code/pretty_qr_code.dart';
import 'package:puppy_dog/controller/puppy_controller.dart';

class AppDialogs {
  static void dialog(bool dismissable, Widget child) {
    Get.generalDialog(
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: dismissable,
      barrierLabel: "",
      barrierColor: Colors.black.withOpacity(0.5),
      pageBuilder: (context, animation, secondaryAnimation) {
        return const SizedBox();
      },
      transitionBuilder: (context, animation, secondaryAnimation, widget) {
        return Transform.scale(
          scale: animation.value,
          child: Opacity(
            opacity: animation.value,
            child: Dialog(
              backgroundColor: Colors.transparent,
              alignment: Alignment.center,
              elevation: 0,
              child: child,
            ),
          ),
        );
      },
    );
  }

  static void loadingDialog() {
    dialog(
      false,
      Container(
        height: 100.h,
        width: 100.w,
        alignment: Alignment.center,
        child: CircularProgressIndicator(
          color: Colors.orange,
          backgroundColor: Colors.orange.shade100,
          strokeWidth: 5.w,
        ),
      ),
    );
  }

  static void errorDialog(
    BuildContext context, {
    required String errorText,
    String? buttonText,
    Function()? function,
  }) {
    dialog(
      false,
      Container(
        width: 428.w,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(10.r),
        ),
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: [
            10.verticalSpace,
            Icon(
              Icons.warning_rounded,
              color: Colors.orange,
              size: 100.sp,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Text(
                errorText,
                textAlign: TextAlign.center,
                style: Get.textTheme.headline4!.copyWith(
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
            20.verticalSpace,
            GestureDetector(
              onTap: () {
                Feedback.forTap(context);
                Get.back();
              },
              child: Container(
                height: 50.h,
                width: 428.w,
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10.r),
                    bottomLeft: Radius.circular(10.r),
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  buttonText ?? "Okay",
                  style: Get.textTheme.button!.copyWith(
                    color: Theme.of(context).colorScheme.surface,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static void paymentSentDialog({required String phoneNumber, required int amount}) async {
    await Get.generalDialog(
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: "",
      barrierColor: Colors.black.withOpacity(0.5),
      pageBuilder: (context, animation, secondaryAnimation) {
        return const SizedBox();
      },
      transitionBuilder: (context, animation, secondaryAnimation, widget) {
        return Transform.scale(
          scale: animation.value,
          child: Opacity(
            opacity: animation.value,
            child: Dialog(
              backgroundColor: Colors.transparent,
              alignment: Alignment.center,
              elevation: 0,
              child: Container(
                width: 428.w,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: ListView(
                  physics: const NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: [
                    30.verticalSpace,
                    SvgPicture.asset(
                      "assets/svg/sent.svg",
                      height: 50.h,
                      fit: BoxFit.fitHeight,
                      color: Colors.orange,
                    ),
                    10.verticalSpace,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Text(
                        phoneNumber != ""
                            ? "\$$amount payment link has been sent to $phoneNumber"
                            : "\$$amount payment link has been created",
                        textAlign: TextAlign.center,
                        style: Get.textTheme.headline4,
                      ),
                    ),
                    30.verticalSpace,
                    GestureDetector(
                      onTap: () {
                        Feedback.forTap(context);
                        Get.back();
                        qrCodeDialog();
                      },
                      child: Container(
                        height: 50.h,
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(10.r),
                            bottomLeft: Radius.circular(10.r),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "View QR code",
                          style: Get.textTheme.button!.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static void qrCodeDialog() async {
    await Get.generalDialog(
      transitionDuration: const Duration(milliseconds: 200),
      barrierDismissible: true,
      barrierLabel: "",
      barrierColor: Colors.black.withOpacity(0.5),
      pageBuilder: (context, animation, secondaryAnimation) {
        return const SizedBox();
      },
      transitionBuilder: (context, animation, secondaryAnimation, widget) {
        return Transform.scale(
          scale: animation.value,
          child: Opacity(
            opacity: animation.value,
            child: Dialog(
              backgroundColor: Colors.transparent,
              alignment: Alignment.center,
              elevation: 0,
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  width: 428.w,
                  padding: EdgeInsets.all(20.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  alignment: Alignment.center,
                  child: PrettyQr(
                    image: const AssetImage("assets/png/puppy.png"),
                    typeNumber: 3,
                    size: 200.sp,
                    data: Get.find<PuppyController>().paymentURL.value,
                    errorCorrectLevel: QrErrorCorrectLevel.M,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
